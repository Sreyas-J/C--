#include<stdio.h>
#include<string.h>
#include "../include/print.h"
//prints the given character
void print_variable(char *token){
    printf("%s\n",token);
}