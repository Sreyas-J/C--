#ifndef CONDITION_H
#define CONDITION_H
#include<stdbool.h>
bool evaluate_condition(int x, char *op, int y);

#endif /* CONDITION_H */
