#ifndef ARITHMETIC_H
#define ARITHMETIC_H

int perform_arithematic(int x, char *op, int y);

#endif /* ARITHMETIC_H */
