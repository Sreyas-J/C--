#ifndef VARIABLE_H
#define VARIABLE_H

void create_variable(char *token);
void assign_variable(char *token);
int get_variable_value(char *var_name);

#endif /* VARIABLE_H */
